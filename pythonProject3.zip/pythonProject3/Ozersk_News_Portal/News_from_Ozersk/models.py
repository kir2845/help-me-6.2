from django.db import models
from django.core.validators import MinValueValidator


class Category(models.Model):                            # Категория, к которой будет привязываться новость

    name = models.CharField(max_length=100, unique=True) # названия категорий тоже не должны повторяться

    def __str__(self):
        return self.name.title()


class New(models.Model):         # Новости для нашей витрины
    name = models.CharField(
        max_length=127,
        unique=True,              # названия товаров не должны повторяться
    )
    time_in = models.DateTimeField(auto_now_add=True)
    textPost = models.TextField()

    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name='news')

    def __str__(self):
        return f'{self.name.title()}: {self.textPost[:40]}'



